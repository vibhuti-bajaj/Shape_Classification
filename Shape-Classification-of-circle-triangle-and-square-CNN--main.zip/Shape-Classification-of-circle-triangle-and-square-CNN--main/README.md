# Shape-Classification-of-circle-triangle-and-square
Image Classification of geometric shapes using CNN 
